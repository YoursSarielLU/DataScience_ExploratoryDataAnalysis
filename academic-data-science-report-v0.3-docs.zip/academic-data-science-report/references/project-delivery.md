# 可复现项目与可视化交付

**阅读说明：** 本文描述项目交付标准。生成文件并不等于运行验证完成；当前自动检查仍有缺口，实际支持范围与复核事项见 [能力与局限](../CAPABILITIES.md)。

## 目录与运行合同

项目至少含 analysis.py、analysis.ipynb、engine/ 实际计算与渲染源码、schemas/、templates/、requirements.txt、research_plan.json 和 README。可选 data/；输出 report/ 内含 summary、validation receipt、environment、tables、figures、report.tex、report.md。Notebook 输出 notebook-report/，避免覆盖 CLI 路径，便于比较。

项目脱离 Skill 源目录仍可运行。Python 路径以 __file__ 所在项目为基准；Notebook 明确以其所在目录启动内核。不得硬编码 Kaggle 路径、个人下载目录或开发机虚拟环境路径。默认批准数据 hash 必须匹配。计划需重新批准时，不提供 --force-approve 等绕过选项。

Notebook 必须有解释性的 Markdown 和实际可执行的阶段单元：配置与门禁、数据检查、计算、图形、校验、报告与局限。调用配套模块是允许的，但模块必须随项目交付且可阅读，不应只有一个隐藏的一键调用。

交付前实际执行 CLI 和新内核 Notebook。核对结果 JSON 与 LaTeX；执行计数和输出应来自本轮运行。保存环境版本。测试更改数据/未批准计划均阻断，缺失/常数/失败场景不输出虚假结果。

## 图形选择

描述问题可用互补视图：

- 全范围直方图展示形状；对数计数轴明确标注，用于显露稀疏尾部。局部面板须写明仅放大视图、未改变样本，最好共享分箱。
- 箱线图展示中位数和四分位数。本适配器须线为实际 min/max，必须说明不是通常的 1.5-IQR 离群点规则。
- ECDF 展示样本累计位置；不受分箱选择影响，但不代表未来事件概率。

不是每个问题都强制三张图；本适配器的三视图是一条已实现的描述路径。未来适配器按 RQ 选择，不能机械生成图集。所有图需可追溯到 analysis/RQ，标明单位、样本处理和轴变换。极端值不能为了美观删除。全缺失/非有限值失败时不画虚假分布。

## 报告与依赖

统计写入 JSON；绘图计算仅在分析侧；渲染器不读取原始 CSV。表格使用已存储的值，图像使用已登记的 artifact。原始文件及工程代码不应被报告渲染改写。

LaTeX 依赖 graphicx、booktabs、placeins、geometry、hyperref，中文用 ctexart 的 Fandol 字体。Python requirements 与 TeX 系统分开说明。运行依赖安装可以联网，但执行数据分析不需要联网。没有 TeX 引擎时明确标记 compilation unverified，不能伪造编译日志或用另一份 PDF 冒充源码编译产物。
