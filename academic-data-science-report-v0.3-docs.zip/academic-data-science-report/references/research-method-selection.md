# v0.3 路由说明

**能力说明：** 下文列出的方法用于研究设计；只有连续变量描述统计有内置执行路径。扩展 EDA 和预测任务需要专属实现、结果契约及测试。参见 [能力与局限](../CAPABILITIES.md)。

下文保留基础统计方法参考。涉及预测/分类/时序/深度学习时，以 [预测研究流程](predictive-research.md) 为准；下文 Sprint 1 的延期表述仅描述内置适配器边界，不限制 Agent 在新获批准方案下生成项目。

# Research method selection — Sprint 1 reference

## General principles and intent

Research Question → Research Intent → Variable Structure → Candidate Method → Suitability / Assumption Check → Final Method. Record rationale at each decision. Variable type alone does not select a test. Each analysis must contribute to an RQ; preserve user-specified methods and surface mismatches for decision. This reference guides planning across the Sprint priorities; only continuous description currently has a bundled execution adapter.

Distinguish description (sample characteristics), association (relationship), group_difference (design-aware comparisons), explanation (adjusted relationships), prediction/classification (unseen-data performance). Segmentation and temporal remain deferred, not invitations to add research scope.

## Variable type system

Separate storage dtype from continuous, ordinal, nominal, binary, datetime, identifier and text semantics; map outcome, predictor, grouping and covariate roles from the RQ. Validate codes, order, units, repeated measurements and sampling design. Numeric IDs are not measurements, numeric categories are not automatically continuous. Text recognition does not authorize NLP.

## Description

Ask which characteristics answer the question. Continuous: mean/SD plus median/IQR/range as relevant, histogram or boxplot for shape. Ordinal: ordered frequencies, median and IQR if meaningful to the coding. Nominal/binary: counts and proportions with explicit denominator and missing counts; bar chart. Datetime: range/frequency and an appropriate temporal plot, no forecasting. Report retained/excluded records. Do not impute, drop duplicates or trim outliers merely to make analysis convenient. The current runner accepts reviewed continuous variables, describes observed values only and does not claim population inference.

## Association

Continuous × continuous: inspect scatterplot, linearity/monotonicity, influential observations and distribution in relation to inferential assumptions. Pearson can describe linear association when appropriate; Spearman can describe rank-monotonic association when justified. Nonlinearity alone does not justify Spearman: a U-shape may be missed by both. State n, coefficient, p-value and suitable CI with its actual computation method; do not invent an interval. Independence comes from study design, not a normality test. If suitability is unresolved, stop and propose an alternative for approval.

Categorical × categorical: inspect contingency table and expected counts. Consider chi-square when its approximation is defensible; sparse 2×2 tables may motivate Fisher exact. Do not silently apply a 2×2 Fisher routine to larger tables. Report chi-square/p where applicable and a justified association effect measure such as Cramér's V. Exact frequency thresholds, larger-table alternatives and CI conventions need method-adapter tests before execution support is claimed.

## Group difference

Confirm independent versus paired observations before checking distributions.

| Design | Candidates | Checks and interpretation |
|---|---|---|
| Two independent groups | Welch/Student t-test; Mann–Whitney U | Independence, influential values, group sizes and distributions; Student additionally needs an appropriate common-variance assumption. Welch is a candidate, not unconditional policy. U concerns ranks/distributions; a median-only interpretation needs additional shape assumptions. |
| Two paired groups | Paired t-test; Wilcoxon signed-rank | Match pairs correctly; analyze within-pair differences and their relevant distribution, missing-pair handling and symmetry for signed-rank. Do not use an independent test on paired data. |
| Three or more independent groups | ANOVA/Welch ANOVA; Kruskal–Wallis | Group sizes, independence, residual/distribution and variance suitability. Omnibus rejection does not identify a specific pair. Specify justified post-hoc comparisons and multiplicity correction before making pairwise claims. |

Report direction, group summaries, effect estimate and appropriate uncertainty, not only significance. Alternatives answer potentially different questions and need a stated rationale; do not switch silently.

## Explanation / regression

Linear regression: continuous outcome, justified predictors/covariates; inspect specification, linearity, collinearity, residual behavior and influential cases. Discuss independence and uncertainty assumptions. Report coefficients, CIs, p-values, R²/adjusted R² and units/reference levels where supplied.

Logistic regression: binary outcome with explicit event coding/reference category; inspect class counts, separation, collinearity, model specification and logit-linearity for continuous predictors. Report coefficients or odds ratios with corresponding intervals, clearly distinguishing odds from probability. Do not substitute a classifier's accuracy for explanatory inference. Neither model establishes causation; do not call feature importance or an adjusted coefficient a causal effect. Thresholds, fitting fallbacks and CI implementation remain adapter work.

## Prediction and classification

RQ must ask about unseen observations, not explanatory significance. Define target and prevent outcome proxies/leakage. Split before learned imputation/scaling/encoding; fit preprocessing only on training folds. Respect groups/repeated records and time order where present. Record actual seed, split and evaluation design in the eventual method contract; this reference does not manufacture default metrics.

Classification path: inspect class counts → choose defensible held-out test or cross-validation → Dummy Classifier baseline → Logistic Regression and/or Random Forest → evaluate on the same untouched test folds. Include confusion matrix, precision, recall and F1 with positive label/averaging stated. ROC-AUC needs suitable scores and class availability; report undefined rather than inventing a value. Never use accuracy alone with imbalance. Do not tune on test results. Small/minority classes may make splitting or evaluation infeasible; warn and redesign with the user.

Regression prediction is part of the wider v0.1 design (baseline, linear/Ridge/Lasso/random forest; MAE/RMSE/R²), but not this Sprint's implementation priority. Avoid expansive tuning/AutoML.

## Segmentation and temporal

Deferred: clustering needs justified features, scaling, cluster evaluation and cautious human interpretation. Temporal description may cover trends, seasonal plots, period comparison and rolling statistics. No forecasting; no ARIMA/Prophet/LSTM. Neither is a Sprint 1 execution path.

## Assumptions, effect size and uncertainty

Record actual observations and consequences of checks; listing names is not evidence that assumptions hold. Distinguish effect magnitude from p-values and practical importance. Report appropriate uncertainty for inferential claims using computed outputs; pure observed-sample description need not add unsupported CIs. No fixed small-p-value threshold automatically dictates a substantive conclusion.

## Methodological warnings and unsupported/causal questions

Absent required variable → answerable=false and critical blocker. Incompatible user method → retain it, explain risk and candidate alternative, requires_user_decision=true. Observational causal request → preserve wording, explain why unanswerable, propose association wording and await decision. Do not reject binary point-biserial Pearson solely because a variable has two levels; coding and intended interpretation matter. The example “Pearson gender versus score and prove gender causes performance” needs separate method/design and causal warnings.

Final decision tree: answerable? → intent/design understood? → variables mapped? → candidates justified? → suitability checks planned? → risks resolved? → user approved? → execute checks and analysis. If post-approval checks fail, stop or use only a specifically approved appropriate fallback; changed scope/method requires revised approval. The bundled runner has no automatic fallback.
