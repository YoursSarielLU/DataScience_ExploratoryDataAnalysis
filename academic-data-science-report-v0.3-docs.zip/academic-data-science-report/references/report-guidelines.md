# Minimal Academic Report Specification

**阅读说明：** 本文描述报告应遵循的标准，并非现有渲染器已完全满足的保证。报告须依据实际计算结果，当前固定文案、中文展示等缺口见 [能力与局限](../CAPABILITIES.md)。

Same verified analysis_summary supplies Markdown and LaTeX. Renderer may format precision (six significant digits in this MVP), but never derive means, ratios, p-values, CIs, model scores or new findings. Null means not estimable, not zero. Report failed analyses explicitly. Use stable analysis/RQ identifiers in Results and Conclusion. No invented citations or dataset background.

1. **Introduction** — supplied background only, objective and exact approved research questions. If background is unknown, state the analytical purpose without manufacturing a population or institution.
2. **Dataset** — file size, relevant variables with technical/semantic types, missingness and obvious quality issues affecting these RQs. Avoid a full EDA dump. Do not assert units or collection design that were not supplied.
3. **Methodology** — what method, which variables, why it answers this RQ, and what suitability checks were actually performed. Distinguish planned checks from observed findings. Explain missing handling, sample SD and quantiles for the executable path. For later inferential methods document uncertainty estimates and design assumptions.
4. **Results** — computed evidence only, grouped by RQ/analysis; figures and table artifacts with captions. No explanations of mechanisms or causal claims. Undefined/failed results stay explicit. Do not silently omit an analysis whose outcome was inconvenient.
5. **Discussion** — distinguish observed evidence, interpretation and speculation explicitly. Explain what the evidence means for each RQ. Unknown practical benchmarks remain unknown; statistical significance is not practical importance. No causal inference from observational associations.
6. **Limitations** — supported issues from data, method, generalization and causal identification. For this minimal input, sampling frame is not established; missingness and duplicates are discussed only when present. Describe one-value/failed analyses when they occur. Avoid asserting unknown bias as proven fact.
7. **Conclusion** — direct answer to each RQ using successful findings with analysis IDs pointing to Results. For failure say unanswered. No new numbers, analyses or mechanisms.

Tables use stored analysis results. Figures are generated on the analysis side after approval. The Markdown includes evidence rows and links to CSV tables; LaTeX includes the same values in booktabs tables and includes the registered figures. Captions explain scales and sample handling.

Escape user strings for Markdown/LaTeX. LaTeX targets XeLaTeX (or compatible Tectonic); Chinese uses ctexart with Fandol fonts, and English uses article. Compilation is a separate QA step when an engine is available, not a promise of PDF delivery.

The renderer is a deliberately conservative narrative baseline for descriptive questions, not an automatic literature review. Review prose against the actual RQ; do not claim subject-specific interpretation that the input cannot support.

## v0.2.1 中文报告的图文组织

中文报告使用 report_zh.tex 和 report_narrative.py。保持七节结构，正文使用纯中文标题、统一字号/行距和底部页码；避免把代码状态、技术 dtype 和 artifact ID 当作主要研究叙述。

结果部分按“统计概览 → 各图及其直接观察”组织。图像采用非浮动块就近放置，不让全部图片漂移到后续页面。每张图包含阅读目标、图形、基于实际数值的观察，以及解释时需要注意的尺度或范围。讨论再综合这些视图，不把方法介绍当作数据结论。

对于实际分位区间跨零、均值/中位数正负等观察，可以根据已存储值选择合适措辞；不得在 Renderer 新算比例、偏度、尾部概率或检验统计量。未经统计检验，不把图形印象写成已证实的正态性、重尾、偏态或可预测性。相同或单值样本需要适配措辞，不重复输出不适用的中心/尾部解释。

丰富内容的目的是解释具体证据，不是追求固定字数。逐图文字应连接已有研究问题和实际位置/离散指标，避免重复泛泛定义，也不能替数据补写未经核验的事件原因。报告中合并语义重复的口径说明时，完整原始警告仍保留在 summary 中。
