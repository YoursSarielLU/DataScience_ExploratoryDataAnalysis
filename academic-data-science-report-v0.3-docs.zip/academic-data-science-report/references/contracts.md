# Minimal contracts and implementation decisions

Current scope and known validation gaps are documented in [Capabilities](../CAPABILITIES.md). These contracts describe the built-in descriptive path; method guidance alone does not add an executable adapter.

The provided v0.1 design is the product baseline. Sprint instructions explicitly authorize resolving only MVP-blocking TBDs. These choices are local Sprint 1 conventions, not revisions of the entire product specification.

## analysis_summary.json

Exactly six top-level fields:

| Field | Meaning |
|---|---|
| research_questions | Approved RQs copied verbatim from the plan, including IDs and origin |
| data_quality | Executed row/column counts, relevant variable types, missing counts and duplicate-row count |
| analyses | One result per plan analysis ID and RQ; method, status, actual suitability observations, results and artifact IDs |
| findings | Engine-produced descriptive answer text with analysis_id and rq_id; not a general claim graph |
| limitations | Supported dataset/method/generalization/causal limitations |
| artifacts | ID, analysis_id, figure/table kind, relative path and caption |

The executable schema supports `descriptive_statistics` now, not arbitrary opaque result dictionaries for future models. Results are keyed by variable and contain n, missing, mean, sample SD (ddof=1), median, q1/q3 (linear interpolation), IQR, min and max. A single observed value has SD=null. Zero observed values or infinities fail the analysis, with empty results. Valid JSON forbids NaN/Infinity. Status is success/failed. A failed analysis has `error`; success has error=null. Error is necessary to explain a missing result without inventing evidence. Assumptions contain actual checks and scope, not false claims that statistical assumptions passed.

`data_quality` records sample context needed to interpret evidence. `findings` references keep Conclusion traceable to Results without a full claim graph. Artifact metadata is needed for captions and file resolution. No scores, graph database or elaborate provenance.

## research_plan.json

Retains the design's seven modules and confirmed enum values. The schema requires its displayed fields; object extras are rejected to catch typos. TBD substructures use minimal strings/lists. Numeric dataset size and provisional technical/semantic types remain separate. Plan allows all eight specified intents and candidate method strings so an unsupported request can be preserved, warned and discussed. The runner only executes its documented method.

Three small gate additions prevent concrete errors:

- `datasets[].sha256`: binds the inspected file to execution; renamed identical bytes are acceptable, edited data require review.
- `approval.plan_sha256`: binds approval to the entire plan except approval bookkeeping; editing RQs, methods, constraints or dataset invalidates approval.
- `approval.user_confirmation`: records the actual user confirmation so setting status alone is insufficient. This is audit context, not proof of identity.

`approved_at` uses UTC ISO timestamps. Modifications are strings. Reject maps to pending. Warnings with requires_user_decision=true block until the user resolves them; warnings without it do not block merely because severity=warning. Critical always blocks. Resolve issues, document the user decision, and reapprove; do not erase evidence of a disputed choice silently.

The CLI supports structured assignment constraints via edited plans. It intentionally blocks unresolved assignment parsing, unsupported required sections and any automatic word limit, rather than pretending to satisfy them. Constraint synonym interpretation and natural-language extraction remain agent responsibilities.

`validation.json` is an external tiny receipt of plan/summary/artifact digests. Validation re-executes the approved deterministic path and compares every computed result and finding. Renderer checks a current receipt; it never re-executes. A current receipt detects later artifact byte changes, but issuing a receipt does not establish that CSV/PNG contents agree with the numerical results. It also does not protect against a malicious editor who forges the receipt. The validator is not an independent statistical implementation; the tests additionally use hand-calculated expected results.

## Capability distinction

Runnable: single-sheet CSV/XLSX → structural inspection → human-reviewed plan → explicit approval → continuous descriptive statistics → checked JSON results plus generated CSV/PNG (artifact content requires review) → seven-section Markdown/LaTeX.

Reference-guided, execution deferred: continuous/categorical association, independent/paired/multiple group comparisons, explanatory linear/logistic regression, classification baseline/logistic/random forest. The schema must be extended with tested method-specific result contracts when these adapters land. This meets Sprint 1's at-least-one-complete-path acceptance criterion, not full v0.1 implementation.

## v0.2 superseding decisions — user-authorized deliverables upgrade

The previous Sprint 1 capability boundary remains for statistical methods. User-authorized additions are portable Python/notebook project delivery, richer RQ-linked descriptive graphics, and a fuller LaTeX report. The six summary top-level fields remain unchanged.

`research_plan.report_context` is optional for compatibility; when present it requires title, language (zh/en), background, variables (label/unit/spread_unit per variable), and limitations. These fields are intended to retain units, domain caveats and language context; they do not guarantee that every renderer preserves them correctly. They participate in the approval digest. They are reviewed source context, not independently verified computed evidence. No future-method schema is added.

The analysis engine now carries supplied limitations and methodological warnings into summary.limitations; validation checks these against a repeat execution. Figure IDs distinguish hist/box/ECDF and link to the same analysis. Renderer includes actual LaTeX tables and figures and formats stored values only. Report text remains a conservative descriptive baseline; user-provided bilingual/background text is not automatically translated or fact-checked.

The exported project includes actual engine code, schemas and templates, with no dependence on the installed Skill. It records an approved plan but never auto-approves another dataset. Notebook and Python use one statistical implementation; agreement is reproducibility evidence, not independent method verification.

## v0.3 predictive workflow

Optional predictive_design records the user-reviewed ML/DL design in the research plan and is covered by the existing whole-plan digest. Bundled descriptive executors and their result schema remain unchanged. Agents implement and test task-specific predictive engines, result schemas and renderers according to predictive-research.md; do not pass model metrics through the descriptive contract. No model training on user data occurred as part of this Skill release.
