# -*- coding: utf-8 -*-
"""Reproducible research entry point. Run from any directory: python analysis.py.

Stages are shared with analysis.ipynb. Source data and the approved plan are immutable
inputs; a changed dataset/plan requires renewed review. No automatic approval.
"""
import argparse
import json
import platform
import sys
from importlib.metadata import version
from pathlib import Path

BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'engine'))
from common import load,save,check_plan,digest,plan_digest,inspect
from run_analysis import run as compute
from generate_figures import generate
from validate_results import verify
from render_report import render

def prepare(dataset=None,output=None):
    plan_path=BASE/'research_plan.json';plan=load(plan_path)
    check_plan(plan,approved=True)
    dataset=Path(dataset) if dataset is not None else BASE/'data'/plan['dataset_understanding']['datasets'][0]['name']
    if not dataset.is_file():raise FileNotFoundError(f'Dataset not found: {dataset}. Supply --dataset PATH; use the approved file unchanged.')
    if digest(dataset)!=plan['dataset_understanding']['datasets'][0]['sha256']:raise ValueError('Dataset changed: obtain a new approved plan')
    output=Path(output) if output is not None else BASE/'report'
    output.mkdir(parents=True,exist_ok=True)
    return dict(plan_path=plan_path,plan=plan,dataset=dataset,output=output)

def inspect_stage(ctx):
    structural=inspect(ctx['dataset']);save(ctx['output']/'inspection.json',structural)
    return structural

def compute_stage(ctx):
    summary=compute(ctx['dataset'],ctx['plan'])
    save(ctx['output']/'analysis_summary.json',summary)
    verify(summary,ctx['plan'],ctx['dataset'],ctx['output'])
    return summary

def figures_stage(ctx,summary):
    summary=generate(ctx['dataset'],ctx['plan'],summary,ctx['output'])
    save(ctx['output']/'analysis_summary.json',summary)
    return summary

def validate_stage(ctx,summary):
    verify(summary,ctx['plan'],ctx['dataset'],ctx['output'])
    receipt=dict(plan_sha256=plan_digest(ctx['plan']),summary_sha256=digest(ctx['output']/'analysis_summary.json'),artifacts={a['path']:digest(ctx['output']/a['path']) for a in summary['artifacts']})
    save(ctx['output']/'validation.json',receipt)
    save(ctx['output']/'environment.json',dict(python=platform.python_version(),packages={p:version(p) for p in ['pandas','numpy','jsonschema','openpyxl','matplotlib','nbformat','nbclient','ipykernel']}))
    return receipt

def report_stage(ctx):
    render(ctx['plan_path'],ctx['output']/'analysis_summary.json',ctx['output']/'validation.json')
    return ctx['output']/'report.tex'

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--dataset',type=Path);p.add_argument('--output',type=Path)
    a=p.parse_args();ctx=prepare(a.dataset,a.output)
    inspect_stage(ctx);summary=compute_stage(ctx);summary=figures_stage(ctx,summary);validate_stage(ctx,summary);report=report_stage(ctx)
    print('Validated report:',report)
    if any(a['status']=='failed' for a in summary['analyses']):
        print('One or more analyses failed; see summary and report.',file=sys.stderr);return 2
    return 0

if __name__=='__main__':sys.exit(main())
