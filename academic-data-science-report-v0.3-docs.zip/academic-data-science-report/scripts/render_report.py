# -*- coding: utf-8 -*-
"""Evidence-to-prose renderer: no dataset input, no statistical recomputation."""
import argparse
import html
import re
from pathlib import Path
from common import load,digest,plan_digest,ROOT,SECTIONS
from validate_results import validate

def tex(text):
    replacements={'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}','−':'-','→':r'$\rightarrow$'}
    return ''.join(replacements.get(c,c) for c in str(text))

def md(text):
    return html.escape(str(text)).replace('|','&#124;').replace('\n',' ').replace('*','&#42;').replace('_','&#95;').replace('`','&#96;').replace('[','&#91;').replace(']','&#93;')

def fmt(value):
    return 'NA' if value is None else f'{value:.6g}' if isinstance(value,float) else str(value)

ZH_LIMITS={
'The supplied file does not establish a sampling frame or representativeness; generalization beyond its observed records is not justified.':'文件本身不能证明样本的代表性，本报告不将结果外推至文件之外的总体或未来时期。',
'Descriptive statistics summarize observed records; they do not test associations, estimate population effects or establish causation.':'描述统计仅概括已观测记录，不检验关联、不估计总体效应，也不建立因果关系。'}

def paragraphs(plan,summary):
    context=plan.get('report_context',{});zh=context.get('language','en')=='zh';dq=summary['data_quality'];out={s:[] for s in SECTIONS}
    out['Introduction']=[plan['research_objective']['statement'],*context.get('background',[])]+[r['id']+': '+r['question'] for r in summary['research_questions']]
    out['Dataset']=[f"数据文件 {plan['dataset_understanding']['datasets'][0]['name']}：{dq['rows']} 行、{dq['columns']} 列，重复行 {dq['duplicate_rows']}。" if zh else f"Dataset {plan['dataset_understanding']['datasets'][0]['name']}: {dq['rows']} rows, {dq['columns']} columns; duplicate rows {dq['duplicate_rows']}."]
    for v in dq['variables']:
        meta=context.get('variables',{}).get(v['name'],{});unit=meta.get('unit','source units')
        out['Dataset'].append(f"{v['name']}：存储类型 {v['data_type']}，语义类型 {v['semantic_type']}；原始单位 {unit}，缺失 {dq['missing'][v['name']]} 条。" if zh else f"{v['name']}: storage {v['data_type']}, semantics {v['semantic_type']}; source unit {unit}; missing {dq['missing'][v['name']]}.")
    planned={a['id']:a for a in plan['analysis_plan']}
    for a in summary['analyses']:
        p=planned[a['analysis_id']]
        out['Methodology'].append(f"{a['analysis_id']} → {a['rq_id']}: {a['method']}. {p['rationale']}")
        out['Results'].append(f"{a['analysis_id']} ({a['rq_id']}): {a['status']}.")
        if a['status']=='failed':
            out['Results'].append(a['error']);continue
        out['Methodology'].append('实际检查确认所选变量为数值型且非缺失值有限。逐变量排除缺失，不填补、不删极端值；未执行独立性或分布假设检验。' if zh else 'Actual checks confirmed numeric variables with finite non-missing observations. Missing values excluded per variable; no imputation or extreme-value deletion. No independence or distribution tests performed.')
        for v,r in a['results'].items():
            meta=context.get('variables',{}).get(v,{});unit=meta.get('unit','source units');spread=meta.get('spread_unit',unit);spread='百分点' if zh and spread=='percentage points' else spread
            if zh:
                observed=f"{v} 的历史观测：均值 {fmt(r['mean'])} {unit}，中位数 {fmt(r['median'])} {unit}；Q1 和 Q3 分别为 {fmt(r['q1'])} {unit} 与 {fmt(r['q3'])} {unit}，IQR 为 {fmt(r['iqr'])} {spread}。"
                conclusion=f"{a['rq_id']}：基于 {r['n']} 条有效记录，{v} 的均值为 {fmt(r['mean'])} {unit}，中位数为 {fmt(r['median'])} {unit}，样本标准差为 {fmt(r['sd'])} {spread}；取值范围为 {fmt(r['min'])} 至 {fmt(r['max'])} {unit}。证据：Results 中的 {a['analysis_id']} 及对应统计表。"
            else:
                observed=f"{v}: observed mean {fmt(r['mean'])} {unit}, median {fmt(r['median'])} {unit}; Q1 {fmt(r['q1'])} {unit}, Q3 {fmt(r['q3'])} {unit}; IQR {fmt(r['iqr'])} {spread}."
                conclusion=f"{a['rq_id']}: based on {r['n']} observed values, {v} has mean {fmt(r['mean'])} {unit}, median {fmt(r['median'])} {unit}, SD {fmt(r['sd'])} {spread}, and range {fmt(r['min'])} to {fmt(r['max'])} {unit}. Evidence: {a['analysis_id']} in Results."
            out['Discussion'].append(('观测证据：' if zh else 'Observed evidence: ')+observed)
            out['Conclusion'].append(conclusion)
    out['Methodology'].append('样本标准差使用 n−1 分母，四分位数使用线性插值。统计表与结论读取同一份已校验 JSON；渲染层仅格式化数值。直方图、箱线图及经验累积分布由分析侧生成。' if zh else 'Sample SD uses n-1; quartiles use linear interpolation. Tables and conclusions read the same validated JSON; rendering formats stored values only. Histogram, box plot and empirical CDF are generated on the analysis side.')
    if any(a['status']=='success' for a in summary['analyses']):
        out['Discussion'].extend(['解释：中位数表示排序后的中心位置；四分位数与 IQR 描述分布的中间部分，标准差和极值补充反映离散程度。三种图形从形状、范围和累计位置回答同一描述性问题，不能单独证明某种理论分布或预测能力。','实践意义取决于单位、数据口径与领域基准，本报告不以统计量大小直接给出实践结论。','推测：不推断产生这些观测的机制或因果关系，也不把经验累计比例当作未来事件概率。'] if zh else ['Interpretation: median describes location; quartiles and IQR describe the central spread, while SD and extrema complement the range. Shape, range and cumulative-position views answer the same descriptive question, not a distributional hypothesis or prediction task.','Practical importance depends on units, data basis and domain benchmarks; no practical threshold is imposed.','Speculation: no causal mechanism or future probability is inferred.'])
    else:
        out['Discussion']=['没有成功的分析，不作分布性解释。' if zh else 'No analysis succeeded; no distributional interpretation is supported.']
    out['Limitations']=[ZH_LIMITS.get(t,t) if zh else t for t in summary['limitations']]
    if zh:
        out['Limitations']=[re.sub(r'^(.*): missing records are excluded from its summary; their missingness mechanism is unknown\.$',r'\1：统计时排除缺失观测；执行器未验证缺失产生机制。',t) for t in out['Limitations']]
    answered={a['rq_id'] for a in summary['analyses'] if a['status']=='success'}
    for rq in summary['research_questions']:
        if rq['id'] not in answered:out['Conclusion'].append(rq['id']+('：分析失败，问题尚未回答。' if zh else ': remains unanswered because no analysis succeeded.'))
    return out

def render(plan_path,summary_path,receipt_path):
    plan=load(plan_path);summary=load(summary_path);receipt=load(receipt_path);root=Path(summary_path).parent
    validate(summary,plan,root)
    if receipt['plan_sha256']!=plan_digest(plan) or receipt['summary_sha256']!=digest(summary_path):raise ValueError('Stale validation receipt')
    if receipt['artifacts']!={a['path']:digest(root/a['path']) for a in summary['artifacts']}:raise ValueError('Artifacts changed after validation')
    context=plan.get('report_context',{});zh=context.get('language','en')=='zh';title=context.get('title','Academic Data Science Report')
    if zh:
        from report_narrative import render_chinese
        render_chinese(plan,summary,root,ROOT/'templates',tex,md)
        return
    blocks=paragraphs(plan,summary); m=['# '+md(title)]; t=[r'\documentclass[UTF8,fontset=fandol]{ctexart}' if zh else r'\documentclass{article}',r'\usepackage{graphicx,booktabs,placeins}',r'\usepackage[margin=23mm]{geometry}',r'\usepackage{hyperref}',r'\title{'+tex(title)+'}',r'\date{}',r'\begin{document}',r'\maketitle']
    translations=['引言','数据集','方法','结果','讨论','局限','结论']
    names=[('n','有效观测'),('missing','缺失'),('mean','均值'),('sd','样本标准差'),('median','中位数'),('q1','第一四分位数'),('q3','第三四分位数'),('iqr','四分位距'),('min','最小值'),('max','最大值')]
    for i,(section,paras) in enumerate(blocks.items()):
        heading=section+' / '+translations[i] if zh else section
        m.append(f'## {i+1}. {heading}');t.append(r'\FloatBarrier\section{'+tex(heading)+'}')
        m.extend(md(p) for p in paras);t.extend(tex(p) for p in paras)
        if section!='Results':continue
        for a in summary['analyses']:
            for v,r in a['results'].items():
                meta=context.get('variables',{}).get(v,{});unit=meta.get('unit','source units');spread=meta.get('spread_unit',unit);spread='百分点' if zh and spread=='percentage points' else spread
                rows=[(label if zh else key,fmt(r[key]),('条' if zh else 'records') if key in ['n','missing'] else spread if key in ['sd','iqr'] else unit) for key,label in names]
                m.append('### '+md(a['analysis_id']+' / '+v));m.append('| '+('指标 | 数值 | 单位' if zh else 'Statistic | Value | Unit')+' |\n|---|---:|---|\n'+'\n'.join('| '+' | '.join(md(c) for c in row)+' |' for row in rows))
                t.extend([r'\begin{table}[htbp]\centering\caption{'+tex(a['analysis_id']+' / '+v)+'}',r'\begin{tabular}{lrl}\toprule',('指标 & 数值 & 单位' if zh else 'Statistic & Value & Unit')+r' \\ \midrule','\n'.join(' & '.join(tex(c) for c in row)+r' \\' for row in rows),r'\bottomrule\end{tabular}\end{table}'])
        for art in summary['artifacts']:
            if art['kind']=='table':m.append(f"[{md(art['id']+' CSV')}]({art['path']})");continue
            caption=art['caption']
            if zh:
                if art['id'].endswith('_hist'):caption='完整范围直方图使用对数计数轴，显示稀疏尾部；右图仅放大中心区域，使用相同数据和分箱，不删除观测。橙线为中位数。'
                elif art['id'].endswith('_box'):caption='箱体表示 Q1 至 Q3，中位数为橙线；须线延伸至实际最小值和最大值，而非 1.5-IQR 离群值边界。全部有限值保留。'
                elif art['id'].endswith('_ecdf'):caption='非缺失值的经验累积分布；参考线标出四分位数和累计比例。该图仅描述历史记录，不是未来收益的概率预测。'
            m.extend([f"![{md(art['id'])}]({art['path']})",md(art['id']+': '+caption)])
            t.extend([r'\begin{figure}[htbp]\centering',r'\includegraphics[width=0.98\linewidth,height=0.33\textheight,keepaspectratio]{'+art['path']+'}',r'\caption{'+tex(art['id']+': '+caption)+r'}\end{figure}'])
    t.append(r'\end{document}')
    markdown=(ROOT/'templates/report.md').read_text(encoding='utf-8').replace('{{Title}}',md(title)).replace('{{Body}}','\n\n'.join(m[1:]))
    latex=(ROOT/'templates/report.tex').read_text(encoding='utf-8').replace('{{DocumentClass}}',t[0]).replace('{{Title}}',tex(title)).replace('{{Body}}','\n\n'.join(t[8:-1]))
    (root/'report.md').write_text(markdown,encoding='utf-8');(root/'report.tex').write_text(latex,encoding='utf-8')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('plan');p.add_argument('summary');p.add_argument('--receipt',required=True)
    a=p.parse_args();render(a.plan,a.summary,a.receipt)
