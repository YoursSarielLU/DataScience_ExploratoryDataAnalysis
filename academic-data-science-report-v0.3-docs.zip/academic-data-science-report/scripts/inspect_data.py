# -*- coding: utf-8 -*-
import argparse
from common import inspect, save
if __name__ == '__main__':
    p=argparse.ArgumentParser(description='Gate-safe structural inspection only')
    p.add_argument('dataset'); p.add_argument('--output',required=True)
    args=p.parse_args(); save(args.output,inspect(args.dataset))
