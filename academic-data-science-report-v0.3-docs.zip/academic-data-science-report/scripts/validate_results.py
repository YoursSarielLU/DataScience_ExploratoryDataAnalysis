# -*- coding: utf-8 -*-
"""Structural checks plus optional independent execution comparison; never called by renderer to compute."""
import argparse
import math
import re
from pathlib import Path
from common import load, save, validate_schema, check_plan, digest, plan_digest

def validate(summary,plan,root=None):
    check_plan(plan,approved=True); validate_schema(summary,'analysis_summary')
    if summary['research_questions']!=plan['research_questions']: raise ValueError('RQ mismatch')
    planned={a['id']:a for a in plan['analysis_plan']}
    analyses={a['analysis_id']:a for a in summary['analyses']}
    if len(analyses)!=len(summary['analyses']) or set(analyses)!=set(planned): raise ValueError('Missing/duplicate/unplanned analyses')
    artifacts={a['id']:a for a in summary['artifacts']}
    if len(artifacts)!=len(summary['artifacts']): raise ValueError('Duplicate artifact IDs')
    for ident,a in analyses.items():
        p=planned[ident]
        if a['rq_id']!=p['rq_id'] or a['method']!=p['proposed_method']: raise ValueError('Analysis linkage mismatch')
        if a['status']=='failed':
            if a['results'] or a['artifacts'] or not a['error']: raise ValueError('Failed analysis contains evidence or lacks error')
        else:
            if a['error'] or set(a['results'])!=set(p['variables']): raise ValueError('Incomplete result')
            for v,r in a['results'].items():
                if r['n']<1 or r['n']+r['missing']!=summary['data_quality']['rows']: raise ValueError('Sample counts inconsistent')
                if r['missing']!=summary['data_quality']['missing'][v]: raise ValueError('Missing counts inconsistent')
                if any(x is not None and not math.isfinite(x) for x in r.values()): raise ValueError('Non-finite results')
                if any(r[k] is None for k in ['mean','median','q1','q3','iqr','min','max']): raise ValueError('Required statistic null')
                if not r['min']<=r['q1']<=r['median']<=r['q3']<=r['max']: raise ValueError('Quantiles inconsistent')
                if not math.isclose(r['iqr'],r['q3']-r['q1']): raise ValueError('IQR inconsistent')
                if (r['n']==1)!=(r['sd'] is None) or (r['sd'] is not None and r['sd']<0): raise ValueError('Invalid SD')
        for ref in a['artifacts']:
            if ref not in artifacts or artifacts[ref]['analysis_id']!=ident: raise ValueError('Broken artifact reference')
    for f in summary['findings']:
        if f['analysis_id'] not in analyses: raise ValueError('Unknown finding evidence')
        a=analyses[f['analysis_id']]
        if a['status']!='success' or f['rq_id']!=a['rq_id']: raise ValueError('Finding has no successful matching evidence')
    for art in artifacts.values():
        if art['analysis_id'] not in analyses or art['id'] not in analyses[art['analysis_id']]['artifacts']: raise ValueError('Orphan artifact')
        path=Path(art['path'])
        if not re.fullmatch(r'(figures|tables)/[A-Za-z0-9_-]+\.(png|csv)',art['path']): raise ValueError('Unsupported artifact path')
        if path.is_absolute() or '..' in path.parts: raise ValueError('Artifact must be relative to report directory')
        if root is not None and not (Path(root)/path).is_file(): raise ValueError('Missing artifact: '+str(path))
    return True

def verify(summary,plan,dataset,root):
    from run_analysis import run
    validate(summary,plan,root)
    expected=run(dataset,plan)
    # Artifact production is separate; compare all computed evidence and derived findings.
    actual={**summary,'artifacts':[],'analyses':[{**a,'artifacts':[]} for a in summary['analyses']]}
    if actual!=expected: raise ValueError('Evidence differs from execution on the approved dataset')

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('plan'); p.add_argument('summary'); p.add_argument('--dataset',required=True); p.add_argument('--receipt',required=True)
    a=p.parse_args(); plan=load(a.plan); summary=load(a.summary)
    root=Path(a.summary).parent; verify(summary,plan,a.dataset,root)
    save(a.receipt,dict(plan_sha256=plan_digest(plan),summary_sha256=digest(a.summary),artifacts={x['path']:digest(root/x['path']) for x in summary['artifacts']}))
    print('Validated against execution on the approved dataset.')
