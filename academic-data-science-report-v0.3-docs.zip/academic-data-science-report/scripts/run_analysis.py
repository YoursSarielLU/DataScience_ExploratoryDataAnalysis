# -*- coding: utf-8 -*-
"""Only implemented statistical path: observed-sample continuous description."""
import argparse
from pathlib import Path
import numpy as np
from common import load, save, check_plan, digest, read_data, validate_schema

def run(dataset, plan):
    check_plan(plan,approved=True)  # Before data loading or any research computation.
    if len(plan['dataset_understanding']['datasets'])!=1 or digest(dataset)!=plan['dataset_understanding']['datasets'][0]['sha256']:
        raise ValueError('Dataset changed: inspect and obtain new proposal approval')
    types={v['name']:v['semantic_type'] for v in plan['dataset_understanding']['variables']}
    rqs={r['id']:r for r in plan['research_questions']}
    for a in plan['analysis_plan']:
        if a['proposed_method']!='descriptive_statistics' or rqs[a['rq_id']]['research_intent']!='description':
            raise ValueError('Unsupported execution path; do not substitute a different method')
        if any(types[v]!='continuous' for v in a['variables']): raise ValueError('Requires reviewed continuous variables')
    frame=read_data(dataset)
    selected=list(dict.fromkeys(v for a in plan['analysis_plan'] for v in a['variables']))
    summary=dict(research_questions=plan['research_questions'],data_quality=dict(rows=len(frame),columns=len(frame.columns),variables=[v for v in plan['dataset_understanding']['variables'] if v['name'] in selected],missing={v:int(frame[v].isna().sum()) for v in selected},duplicate_rows=int(frame.duplicated().sum())),analyses=[],findings=[],limitations=['The supplied file does not establish a sampling frame or representativeness; generalization beyond its observed records is not justified.','Descriptive statistics summarize observed records; they do not test associations, estimate population effects or establish causation.'],artifacts=[])
    for a in plan['analysis_plan']:
        result={}; error=None
        try:
            for v in a['variables']:
                if not np.issubdtype(frame[v].dtype,np.number): raise ValueError(f'{v}: non-numeric values; resolve coding and reapprove')
                x=frame[v].dropna()
                if not np.isfinite(x).all(): raise ValueError(f'{v}: non-finite values; no silent removal')
                if len(x)==0: raise ValueError(f'{v}: no observed values')
                q1=float(x.quantile(.25)); q3=float(x.quantile(.75))
                result[v]=dict(n=len(x),missing=int(frame[v].isna().sum()),mean=float(x.mean()),sd=float(x.std(ddof=1)) if len(x)>1 else None,median=float(x.median()),q1=q1,q3=q3,iqr=q3-q1,min=float(x.min()),max=float(x.max()))
        except (ValueError,TypeError) as exc:
            error=str(exc); result={}
        record=dict(analysis_id=a['id'],rq_id=a['rq_id'],method=a['proposed_method'],status='failed' if error else 'success',assumptions=dict(suitability=error or 'Reviewed continuous semantics and finite observed numeric values confirmed.',missingness='Available observations per variable; no imputation; duplicates retained.',inference='Observed-sample description only; no normality or independence assumption used for inference.'),results=result,artifacts=[],error=error)
        summary['analyses'].append(record)
        if error:
            summary['limitations'].append(f"{a['id']} failed: {error}")
        else:
            for v,r in result.items():
                summary['findings'].append(dict(analysis_id=a['id'],rq_id=a['rq_id'],text=f"{v}: observed mean {r['mean']:.6g}, median {r['median']:.6g}, IQR {r['iqr']:.6g}, based on {r['n']} non-missing records. These summarize the supplied sample only."))
                if r['missing']: summary['limitations'].append(f'{v}: missing records are excluded from its summary; their missingness mechanism is unknown.')
                if r['n']==1: summary['limitations'].append(f'{v}: only one observed value; sample SD is undefined.')
    if summary['data_quality']['duplicate_rows']: summary['limitations'].append('Duplicate rows were retained; without record identifiers their legitimacy cannot be determined.')
    context=plan.get('report_context',{})
    summary['limitations'].extend(context.get('limitations',[]))
    summary['limitations'].extend(w['issue'] for w in plan['methodological_warnings'])
    summary['limitations']=list(dict.fromkeys(summary['limitations']))
    validate_schema(summary,'analysis_summary')
    return summary

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('dataset'); p.add_argument('plan'); p.add_argument('--output',required=True)
    a=p.parse_args(); save(a.output,run(a.dataset,load(a.plan)))
