# -*- coding: utf-8 -*-
"""Export portable Python + notebook + runtime sources; never approve plans here."""
import argparse
import shutil
from pathlib import Path
import nbformat as nbf
from common import ROOT,load,check_plan,digest,save

def export(plan_path,dataset,output,include_data=False):
    plan=load(plan_path);check_plan(plan,approved=True)
    dataset=Path(dataset);output=Path(output)
    if digest(dataset)!=plan['dataset_understanding']['datasets'][0]['sha256']:raise ValueError('Dataset changed')
    if output.exists() and any(output.iterdir()):raise ValueError('Export requires a new or empty project directory')
    output.mkdir(parents=True,exist_ok=True)
    for directory in ['schemas','references','templates']:
        shutil.copytree(ROOT/directory,output/directory)
    shutil.copytree(ROOT/'scripts',output/'engine',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    shutil.copy2(ROOT/'templates/analysis.py',output/'analysis.py')
    shutil.copy2(ROOT/'requirements.txt',output/'requirements.txt')
    shutil.copy2(plan_path,output/'research_plan.json')
    (output/'data').mkdir()
    if include_data:shutil.copy2(dataset,output/'data'/plan['dataset_understanding']['datasets'][0]['name'])
    nb=nbf.v4.new_notebook();nb.metadata.kernelspec=dict(name='python3',display_name='Python 3',language='python');nb.metadata.language_info=dict(name='python')
    md=nbf.v4.new_markdown_cell;code=nbf.v4.new_code_cell
    nb.cells=[
        md('# '+plan.get('report_context',{}).get('title','Academic analysis')+'\n\n本 Notebook 与 `analysis.py` 共用可阅读的 `engine/` 源码。仅执行已批准的研究，不访问网络或自动安装依赖。请使用项目虚拟环境，从本 Notebook 所在目录启动内核，按顺序 Run All。'),
        md('## 1. 配置与批准检查\n路径以项目目录为基准。更换数据或方案会触发门禁，不能仅改文件名继续。'),
        code("from pathlib import Path\nfrom IPython.display import display, Markdown, Image\nimport pandas as pd\nfrom analysis import prepare, inspect_stage, compute_stage, figures_stage, validate_stage, report_stage\n\nDATASET = None  # None uses the included approved data; otherwise set an explicit Path.\nOUTPUT = Path('notebook-report')\nctx = prepare(DATASET, OUTPUT)\ndisplay(Markdown('**Research objective:** ' + ctx['plan']['research_objective']['statement']))\nfor rq in ctx['plan']['research_questions']:\n    display(Markdown(rq['id'] + ': ' + rq['question']))"),
        md('## 2. 数据结构与语义审阅\n自动类型是提示；实际分析使用已经审阅并批准的计划语义。缺失按选定变量处理，不全表 dropna。'),
        code("inspection = inspect_stage(ctx)\ndisplay(pd.DataFrame(inspection['datasets']))\ndisplay(pd.DataFrame(ctx['plan']['dataset_understanding']['variables']))\nfor warning in ctx['plan']['methodological_warnings']:\n    print(warning['severity'] + ': ' + warning['issue'])"),
        md('## 3. 描述统计\n样本标准差使用 n−1；四分位数采用线性插值。失败分析不生成虚假数值。计算后与批准数据的重复执行结果核对。'),
        code("summary = compute_stage(ctx)\nfor analysis in summary['analyses']:\n    print(analysis['analysis_id'], analysis['status'])\n    if analysis['status'] == 'success':\n        display(pd.DataFrame.from_dict(analysis['results'], orient='index'))\n    else:\n        print(analysis['error'])"),
        md('## 4. 图形证据\n同一 RQ 使用互补视图：全范围与中心视图、四分位数和完整范围、经验累积分布。放大区域不改变分析样本；箱须是极值而非离群值判定线。'),
        code("summary = figures_stage(ctx, summary)\nfor artifact in summary['artifacts']:\n    if artifact['kind'] == 'figure':\n        display(Markdown('### ' + artifact['id'] + '\\n' + artifact['caption']))\n        display(Image(filename=str(ctx['output'] / artifact['path'])))"),
        md('## 5. 校验与 LaTeX 报告\n渲染器只读取已校验结果；不在写作时重新计算统计量。报告保留方案中的口径和方法风险。'),
        code("receipt = validate_stage(ctx, summary)\nreport_path = report_stage(ctx)\nprint('LaTeX:', report_path)\nprint('Markdown:', ctx['output'] / 'report.md')\nprint('Analysis summary:', ctx['output'] / 'analysis_summary.json')\nprint('Evidence validation passed.')"),
        md('## 6. 研究局限与复现\n不要将历史样本分布解释为未来预测或因果效应。`report/report.tex` 与 `notebook-report/report.tex` 分别来自 CLI 和 Notebook 路径。可比较两者的结果 JSON；图像字节可能随字体/绘图版本变化。'),
        code("for limitation in summary['limitations']:\n    print('- ' + limitation)\nassert all(a['status'] == 'success' for a in summary['analyses']), 'Analysis failed; see outputs before drawing conclusions.'")]
    nbf.write(nb,output/'analysis.ipynb')
    (output/'README.md').write_text('''# 可复现学术分析项目

本目录包含实际分析代码 `analysis.py`、逐步执行的 `analysis.ipynb`、完整 `engine/` 源码、结果 Schema 和已批准的 `research_plan.json`。不是依赖原开发机器的启动壳。

## 运行

Python 3.9+。从此目录创建虚拟环境并安装依赖：

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python analysis.py
```

Windows 将 `.venv/bin/python` 换成 `.venv\\Scripts\\python.exe`。输入默认位于 `data/`。若未随包提供，使用 `--dataset /path/to/approved.csv`，文件内容必须与已批准计划匹配。不要绕过 hash 或自动批准新数据。

`analysis.py` 可从任意工作目录运行；可用 `--output DIR` 指定结果目录。运行后生成 JSON、CSV 表、PNG 图、Markdown 与 LaTeX。失败会返回非零退出码。

## Notebook

在 VS Code/Jupyter 中打开 `analysis.ipynb`，选择上述虚拟环境的 Python 内核，以项目目录为工作目录，Restart Kernel and Run All。无需修改隐藏状态。Notebook 将结果写到 `notebook-report/`，CLI 默认写到 `report/`。运行所需 nbformat、nbclient、ipykernel 已列入 requirements；JupyterLab 前端按用户环境另行提供。

## LaTeX

报告中文模式使用 ctexart 与 Fandol 字体。在报告目录执行：

```bash
xelatex -interaction=nonstopmode -halt-on-error report.tex
xelatex -interaction=nonstopmode -halt-on-error report.tex
```

也可在有 Tectonic 的环境运行 `tectonic report.tex`。若缺少 TeX 环境，只能确认源文件生成，不能声称编译已验证。不要修改统计数字修复排版。

## 授权与范围

该计划记录的是本项目的用户批准，不是任何其他数据集的通用授权。所有计算在本地进行；依赖安装和首次 TeX 包下载可能需要网络。当前执行器只实现连续变量描述统计；没有模型训练、预测或自动联网行情采集。

`report_context` 中的来源背景、单位和局限经计划批准后进入报告；数据、方法、单位或研究问题变化必须重新审阅。程序保留极端值，不为画图静默改变数据。
''',encoding='utf-8')
    return output

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('plan');p.add_argument('dataset');p.add_argument('--output',required=True);p.add_argument('--include-data',action='store_true',help='Copy approved dataset into this local project; never use for the public Skill package')
    a=p.parse_args();print(export(a.plan,a.dataset,a.output,a.include_data))
