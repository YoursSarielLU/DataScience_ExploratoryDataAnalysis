# -*- coding: utf-8 -*-
"""Contracts and lightweight inspection. No formal research statistics here."""
import hashlib
import json
import math
from pathlib import Path
import jsonschema
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
SECTIONS = ['Introduction','Dataset','Methodology','Results','Discussion','Limitations','Conclusion']

def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'), parse_constant=lambda x: (_ for _ in ()).throw(ValueError('Non-finite JSON: '+x)))

def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False)+'\n', encoding='utf-8')

def validate_schema(value, name):
    jsonschema.Draft202012Validator(load(ROOT/'schemas'/f'{name}.schema.json')).validate(value)

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def plan_digest(plan):
    body = {k:v for k,v in plan.items() if k != 'approval'}
    return hashlib.sha256(json.dumps(body, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()).hexdigest()

def read_data(path):
    path = Path(path)
    if path.suffix.lower() == '.csv':
        frame = pd.read_csv(path)
    elif path.suffix.lower() == '.xlsx':
        with pd.ExcelFile(path) as book:
            if len(book.sheet_names) != 1:
                raise ValueError('MVP requires a single-sheet XLSX; select/export the intended sheet first.')
            frame = pd.read_excel(book)
    else:
        raise ValueError('Only CSV/XLSX supported')
    frame.columns = frame.columns.map(str)
    if frame.empty or not frame.columns.is_unique:
        raise ValueError('Empty data or duplicate column names')
    return frame

def inspect(path):
    frame = read_data(path)
    variables=[]
    for name, series in frame.items():
        low=name.lower()
        if low == 'id' or low.endswith('_id'):
            semantic='identifier'
        elif pd.api.types.is_datetime64_any_dtype(series):
            semantic='datetime'
        elif series.nunique() == 2:
            semantic='binary'
        elif pd.api.types.is_numeric_dtype(series):
            semantic='continuous'
        else:
            semantic='nominal'
        variables.append(dict(name=name,data_type=str(series.dtype),semantic_type=semantic,possible_role='undetermined'))
    issues=['Semantic types are provisional: verify coding, units, identifiers and ordinal scales with the user.']
    for name in frame:
        if frame[name].isna().any(): issues.append(f'{name}: missing values present.')
    if frame.duplicated().any(): issues.append('Duplicate rows present; retained unless user approves a justified change.')
    return dict(datasets=[dict(name=Path(path).name,rows=len(frame),columns=len(frame.columns),sha256=digest(path))],variables=variables,potential_issues=issues)

def check_plan(plan, approved=False):
    validate_schema(plan,'research_plan')
    for key in ['research_questions','analysis_plan','methodological_warnings']:
        ids=[x['id'] for x in plan[key]]
        if len(ids)!=len(set(ids)): raise ValueError('Duplicate IDs: '+key)
    rqs={r['id']:r for r in plan['research_questions']}
    names={v['name'] for v in plan['dataset_understanding']['variables']}
    for a in plan['analysis_plan']:
        if a['rq_id'] not in rqs: raise ValueError('Unknown RQ')
        roles={v for vs in rqs[a['rq_id']]['variables'].values() for v in vs}
        if not set(a['variables']) <= roles: raise ValueError('Analysis variables not mapped to RQ')
    if not approved: return
    ap=plan['approval']
    if ap['status']!='approved' or not ap['approved_at'] or not ap['user_confirmation']:
        raise ValueError('Research Proposal Gate: explicit user approval required')
    if ap['plan_sha256']!=plan_digest(plan): raise ValueError('Plan changed: obtain new approval')
    if not rqs or not plan['analysis_plan']: raise ValueError('Choose research questions before execution')
    if any(not r['answerable'] for r in rqs.values()): raise ValueError('Unanswerable RQ')
    if any(w['severity']=='critical' or w['requires_user_decision'] for w in plan['methodological_warnings']):
        raise ValueError('Unresolved methodological warning or critical blocker')
    if any(not set(a['variables'])<=names for a in plan['analysis_plan']): raise ValueError('Missing variable')
    c=plan['task_context']['constraints']
    methods={a['proposed_method'] for a in plan['analysis_plan']}
    if not set(c['required_methods'])<=methods or methods & set(c['prohibited_methods']):
        raise ValueError('Assignment method constraint conflict')
    if not set(c['required_sections'])<=set(SECTIONS): raise ValueError('Unsupported assignment section constraint')
    if c['word_limit'] is not None: raise ValueError('Automatic word-limit enforcement deferred; resolve before this runner')
