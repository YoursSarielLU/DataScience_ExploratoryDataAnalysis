# -*- coding: utf-8 -*-
"""Chinese narrative and editorial layout over stored evidence; no dataset access.

Value formatting and order comparisons select appropriate prose. No statistical
quantity, percentage, interval, test or model is computed in the writing layer.
"""
from pathlib import Path


def render_chinese(plan,summary,root,templates,escape,markdown_escape):
    meta=plan.get('report_context',{}); title=meta.get('title','数据描述研究报告')
    m=['# '+markdown_escape(title)];t=[]
    def para(text):
        m.append(markdown_escape(text));t.append(escape(text))
    def section(title):
        m.append('## '+title);t.append(r'\section{'+escape(title)+'}')
    def sub(title):
        m.append('### '+title)
        reserve=r'0.43\textheight' if title.startswith(('直方图','箱线图','经验累积分布')) else r'5\baselineskip'
        t.append(r'\Needspace{'+reserve+r'}\subsection{'+escape(title)+'}')
    def num(v):
        if v is None:return '不可估计'
        return f'{v:.4f}' if isinstance(v,float) else f'{v:,}'
    def block(paras):
        for p in paras:para(p)
    figures=[a for a in summary['artifacts'] if a['kind']=='figure']
    figs={a['id']:i+1 for i,a in enumerate(figures)}
    def figure(art,caption):
        n=figs[art['id']]
        m.extend([f"![图{n}]({art['path']})",f'图{n}　'+markdown_escape(caption)])
        # A non-floating block prevents graphs from migrating away from their text.
        t.extend([r'\par\medskip\noindent\begin{minipage}{\linewidth}\centering',r'\includegraphics[width=\linewidth,height=0.28\textheight,keepaspectratio]{'+art['path']+'}',r'\par\smallskip\raggedright{\small\textbf{图'+str(n)+r'　}'+escape(caption)+r'\par}',r'\end{minipage}\par\medskip'])
    success=[a for a in summary['analyses'] if a['status']=='success']
    known=[(a,v,r) for a in success for v,r in a['results'].items()]
    def display(v):
        label=meta.get('variables',{}).get(v,{}).get('label',v)
        return {'Daily return':'日收益率','daily_return_pct':'日收益率'}.get(label,label)
    def units(v):
        item=meta.get('variables',{}).get(v,{})
        u=item.get('unit','源数据单位');d=item.get('spread_unit',u)
        return u,{'percentage points':'个百分点'}.get(d,d)
    def val(v,r,k):
        u,d=units(v);return num(r[k])+(' '+d if k in ['sd','iqr'] else u)
    section('引言')
    block([plan['research_objective']['statement'],*meta.get('background',[])])
    para('描述一组观测时，单一均值不足以交代数据的整体面貌：相近的中心位置可以对应不同的离散程度，而少量远离中心的记录又可能在全范围图中占据很长的横轴。因此，本报告将数值概览与互补图形结合，分别考察分布中心、四分位范围和两端观测。')
    for rq in summary['research_questions']:para('研究问题：'+rq['question'])
    para('下文先说明数据口径和处理方法，再逐图陈述可直接观察到的证据，最后讨论这些证据对研究问题的含义。图形解释不替代统计检验；没有实施的检验、时序分析和预测不作为本报告的结论。')
    section('数据与研究范围')
    dq=summary['data_quality'];ds=plan['dataset_understanding']['datasets'][0]
    para(f"输入文件为 {ds['name']}，包含 {dq['rows']:,} 条记录和 {dq['columns']} 个字段。结构检查记录的重复行为 {dq['duplicate_rows']} 条。研究仅使用获批问题对应的变量，其他字段存在缺失并不会自动导致本分析删除整行记录。")
    for a,v,r in known:
        u,d=units(v)
        para(f"本次分析的{display(v)}对应字段 {v}。其中 {r['n']:,} 条记录有可用数值，{r['missing']} 条记录缺失。该变量按源字段标注的 {u} 刻度报告，原始值不额外缩放；标准差和四分位距按 {d} 报告，以区别位置数值与差异大小。")
    para('数据完整性检查和数据来源真实性核验是不同任务。文件可被读取、数值有限、字段结构一致，并不自动意味着记录已与外部原始来源逐条核对。本报告保留数据提供者说明的口径限制，适用范围是给定文件及获批变量。')
    section('研究方法')
    sub('统计量与样本处理')
    para('对每个获批变量分别统计有效观测数和缺失数，并报告均值、中位数、样本标准差、第一与第三四分位数、四分位距及最小和最大值。均值概括数值平均水平，中位数描述排序后的中心位置；两者联合使用，避免将一种中心指标当作分布的全部信息。')
    para('样本标准差采用 n−1 分母；四分位数采用线性插值，四分位距由分析程序计算。缺失观测仅在对应变量的统计中排除，不填补缺失值，不因幅度较大而删去有限观测。没有实施分布检验或总体推断，因此不报告 p 值或置信区间。')
    sub('互补可视化的阅读方式')
    para('直方图展示不同取值区间的观测数量：全范围面板保留两端记录，并用对数计数轴提高稀疏柱的可见性；中心面板使用相同数据和分箱，只改变显示范围。两个面板的纵轴尺度不同，柱高不能跨面板直接比较。')
    para('箱线图用箱体表示第一至第三四分位数，并标出中位数。本报告将须线明确延伸至实际最小值与最大值，而不是通常的 1.5 倍四分位距规则，因此不利用须线判定“异常记录”。经验累积分布图则按观测排序展示累计位置，不依赖直方图的分箱选择。')
    para('统计表、正文数字和图形均对应同一份经校验的分析结果。报告生成层只读取已有数值；更换文字或排版不会重新计算样本统计，也不会改变纳入分析的记录。')
    section('结果：统计概览与图形证据')
    if not known:para('本次没有成功的分析结果，不能据此描述分布。失败原因保留在分析结果文件中；相关研究问题尚未回答。')
    table_idx=0
    for a,v,r in known:
        table_idx+=1;name=display(v);u,d=units(v)
        sub(name+'的统计概览')
        para(f"表{table_idx}汇总{r['n']:,}条有效观测。均值为{val(v,r,'mean')}，中位数为{val(v,r,'median')}；样本标准差为{val(v,r,'sd')}。这些指标分别描述中心位置和离散程度，单位与源字段保持一致。")
        rows=[('有效观测',num(r['n']),'条'),('缺失观测',num(r['missing']),'条')]+[(lab,num(r[k]),d if k in ['sd','iqr'] else u) for k,lab in [('mean','均值'),('median','中位数'),('sd','样本标准差'),('q1','第一四分位数'),('q3','第三四分位数'),('iqr','四分位距'),('min','最小值'),('max','最大值')]]
        m.append('| 指标 | 数值 | 单位 |\n|---|---:|---|\n'+'\n'.join('| '+' | '.join(markdown_escape(c) for c in row)+' |' for row in rows))
        t.extend([r'\par\medskip\noindent\begin{minipage}{\linewidth}\centering',r'{\small\textbf{表'+str(table_idx)+'　'+escape(name+'的描述统计')+r'}\par}\smallskip',r'\renewcommand{\arraystretch}{1.12}\begin{tabular}{lrl}\toprule',r'指标 & 数值 & 单位 \\ \midrule','\n'.join(' & '.join(escape(c) for c in row)+r' \\' for row in rows),r'\bottomrule\end{tabular}\end{minipage}\par\medskip'])
        para(f"第一四分位数为{val(v,r,'q1')}，第三四分位数为{val(v,r,'q3')}，四分位距为{val(v,r,'iqr')}。这两个分位点界定样本中间部分的位置，比只给出极值更适合描述典型观测的分布范围；由于采用插值，分位数不一定等于某一条原始记录。")
        if r['q1'] < 0 < r['q3']:
            para('第一四分位数在零以下，第三四分位数在零以上，中间部分的分位区间因此横跨正负两侧。这说明中心位置与正负取值的分布需要同时阅读，不能只引用均值来概括全部观测。')
        para(f"最小值与最大值分别为{val(v,r,'min')}和{val(v,r,'max')}。它们是本窗口内已经出现的观测端点，不是未来变化的上下界。后续图形将这两个端点与四分位区间放在同一尺度下展示。")
        arts=[x for x in figures if x['analysis_id']==a['analysis_id'] and x['id'] in a['artifacts']]
        # Match variable index through the stable artifact ID contract.
        j=list(a['results']).index(v)+1
        arts=[x for x in arts if f'_{j}_' in x['id']]
        for art in arts:
            n=figs[art['id']]
            if art['id'].endswith('_hist'):
                sub('直方图：中心区域与完整取值范围')
                para(f"图{n}将同一组{ name }观测置于两个视图中。全范围面板显示完整横轴及稀疏计数，中心面板便于阅读中位数附近的柱形结构；橙色参考线的位置为{val(v,r,'median')}。局部放大只改变显示方式，表中的统计量仍使用全部有效观测。")
                figure(art,'完整范围与中心视图的直方图。左图纵轴为对数计数，右图为普通计数；数据与分箱一致。橙线标出中位数，中心面板之外的观测没有从分析中删除。')
                para(f"阅读中心面板时，应将柱形轮廓与第一、第三四分位数{val(v,r,'q1')}和{val(v,r,'q3')}联系起来；阅读完整面板时，则应留意横轴延伸到{val(v,r,'min')}与{val(v,r,'max')}的两端观测。两种视图的作用不同：前者让中心区域更容易分辨，后者防止局部视图掩盖样本端点。")
                para('对数轴压缩计数差异，使较少出现的区间仍然可见。因此，尾部某个柱形在图上看起来明显，并不表示该区间与中心区域同样常见。直方图的轮廓还会受到分箱选择影响；本图用于描述实际样本，不据此宣布数据服从正态分布或具有某种经检验确认的尾部性质。')
            elif art['id'].endswith('_box'):
                sub('箱线图：四分位区间与观测端点')
                para(f"图{n}将中位数、四分位区间和完整取值范围放在一条横轴上。箱体从{val(v,r,'q1')}延伸到{val(v,r,'q3')}，其中位数线位于{val(v,r,'median')}；箱体宽度对应已计算的四分位距{val(v,r,'iqr')}。")
                figure(art,'箱体覆盖第一至第三四分位数，橙线为中位数；须线到达实际最小和最大观测，不使用 1.5-IQR 规则判定离群值。')
                if r['min']<r['q1'] and r['max']>r['q3']:
                    para('箱体与两端须线区分了“中间部分的位置”和“整个样本曾达到的范围”。须线延伸到箱体之外，说明仅用四分位区间不能交代所有记录；但须线长度也不提供相应区间内的观测频数，必须结合直方图或累积分布阅读。')
                else:
                    para('在取值重复较多或范围较窄的样本中，箱体和部分须线可能重合。这不是遗漏记录，而是若干位置统计量相同造成的显示结果，不能据图形退化断言计算失败。')
                para(f"样本标准差为{val(v,r,'sd')}，而四分位距为{val(v,r,'iqr')}。两者都是离散程度指标，但概括方式不同：标准差使用全部有效值，四分位距围绕排序后的中间部分。报告同时给出两者，是为了呈现不同视角，不将它们当作同一种尺度的可替代估计。")
            elif art['id'].endswith('_ecdf'):
                sub('经验累积分布：摆脱分箱后的累计位置')
                para(f"图{n}把横轴上的每个取值与样本中不大于该值的累计比例联系起来。与直方图不同，它不需要先选择分箱宽度；曲线较陡的区域表示较多观测集中在相对较窄的数值区间，较平缓的区域表示新增观测较少。")
                figure(art,'全部非缺失观测的经验累积分布。参考线对应四分位位置与累计比例；该曲线描述历史样本，不作为未来事件的概率预测。')
                para(f"四分位数{val(v,r,'q1')}、{val(v,r,'median')}和{val(v,r,'q3')}提供了阅读累计位置的参照。它们来自同一份结果表，而不是在图上目测后重新估计。经验曲线具有阶梯性质；插值得到的分位位置与具体阶梯跳点不必完全重合。")
                para('本图保留了从最小到最大观测的整个横轴范围，因此同时呈现中心区域的累积变化和两端的延伸。它有助于检查直方图的印象是否依赖某一种分箱，但仍不能回答观测发生的时间顺序，也不能识别某次极端变化对应的市场事件。')
    section('讨论：三类图形如何共同回答研究问题')
    if known:
        sub('中心位置与离散程度需要同时阅读')
        for a,v,r in known:
            para(f"对{display(v)}而言，均值{val(v,r,'mean')}与中位数{val(v,r,'median')}给出了两种中心概括；四分位区间从{val(v,r,'q1')}到{val(v,r,'q3')}，补充了中间部分的分布位置。研究问题因此不能只用一个均值作答，还应同时交代样本围绕中心的分散程度和实际端点。")
        for a,v,r in known:
            if r['mean'] > 0 and r['median'] > 0 and r['q1'] < 0 < r['q3']:
                para(f'{display(v)}的均值和中位数均位于零以上，但下四分位数仍在零以下，上四分位数在零以上。因此，正的中心指标与样本包含负值并不矛盾；它既不是每条记录都为正的证据，也不是对未来取值的保证。')
            if r['mean'] > r['median']:
                para(f'该样本的均值高于中位数，这是两种位置指标在实际数据中的差别。但均值与中位数的相对位置不足以单独确定偏度或解释形成机制；本研究没有计算偏度，也没有据此作分布检验。')
        para('三张图各有明确分工。直方图强调区间计数和局部形状；箱线图把中位数、四分位数和端点压缩为可比较的位置关系；经验累积分布从排序角度检查累计变化。它们提供互补证据，而不是三个彼此独立的统计检验。')
        sub('图中的尾部观测与未经验证的解释')
        para('完整范围图保留极端记录，是为了避免把历史样本呈现得过于平稳。然而，保留某条记录不等于已经确认它反映真实外部事件；数据口径、记录质量以及事件背景仍需额外证据。这里既不因其幅度较大而删除，也不为其补写未经核验的原因。')
        para('同时，样本端点和四分位区间描述的是不同部分。不能把端点当作典型观测，也不能将箱体之外的全部记录称为错误或异常。若要进一步量化尾部频率、比较时期或检验分布，需要在新的分析范围内明确指标与方法，不能从当前图形中读出尚未计算的数字。')
        sub('历史汇总的适用范围')
        para('这组图将获批窗口内的观测合并展示，因此能够回答样本分布是什么样，却不能单独回答分布是否随时间改变。即使完整窗口的中心位置已知，也不能据此推断某一个未来时点的取值；同样的总体形状可能对应不同的时间排列。')
        para('本报告因此将观察与推测分开：数值表和图形给出文件中的经验描述，讨论解释这些视图如何帮助理解位置与离散程度；有关未来表现、行为机制或因果关系的判断不属于现有证据能够支持的范围。')
    else:para('没有可用结果，不作解释。')
    section('局限与证据边界')
    # Preserve all approved caveats. Group them into paragraphs rather than a list of fragments.
    from render_report import ZH_LIMITS
    import re
    limits=[]
    for raw in summary['limitations']:
        text=ZH_LIMITS.get(raw,raw)
        text=re.sub(r'^(.*): missing records are excluded from its summary; their missingness mechanism is unknown\.$',r'\1：统计时排除缺失观测，执行器未验证缺失机制。',text)
        if text not in limits:limits.append(text)
    # Near-duplicate source-basis warnings are grouped, not silently discarded from evidence.
    source=[x for x in limits if '调整参数未知' in x]
    rest=[x for x in limits if x not in source]
    if source:
        para('来源与口径方面，'+source[0])
        for x in source[1:]:
            if not all(word in source[0] for word in ['调整参数未知','公式','总回报']):para(x)
    for start in range(0,len(rest),2):para(' '.join(rest[start:start+2]))
    section('结论')
    for a,v,r in known:
        para(f"针对获批研究问题，{r['n']:,}条有效记录表明：{display(v)}的均值为{val(v,r,'mean')}，中位数为{val(v,r,'median')}；四分位区间由{val(v,r,'q1')}至{val(v,r,'q3')}，样本标准差为{val(v,r,'sd')}，观测端点为{val(v,r,'min')}和{val(v,r,'max')}。以上数值均见本报告结果部分，证据对应分析 {a['analysis_id']}。")
    if known:para('直方图、箱线图与经验累积分布共同补充了这些数字的含义：既展示中心区域，也保留整个样本的范围，并明确区分图形视角与统计推断。结论限于所提供数据的描述，不外推为未来表现或因果解释。')
    answered={a['rq_id'] for a in success}
    for rq in summary['research_questions']:
        if rq['id'] not in answered:para(rq['id']+'：由于相关分析未成功，该问题尚未回答。')
    (root/'report.md').write_text('\n\n'.join(m)+'\n',encoding='utf-8')
    template=(templates/'report_zh.tex').read_text(encoding='utf-8')
    (root/'report.tex').write_text(template.replace('{{Title}}',escape(title)).replace('{{Body}}','\n\n'.join(t)),encoding='utf-8')
