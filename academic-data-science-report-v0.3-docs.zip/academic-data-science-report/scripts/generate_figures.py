# -*- coding: utf-8 -*-
"""RQ-linked distribution views. Only the analysis side calculates plotting arrays."""
import argparse
import csv
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
from common import load, save, digest, read_data
from validate_results import validate

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.titleweight':'bold','axes.titlepad':12,'savefig.facecolor':'white'})
BLUE='#176b91'; ORANGE='#bb4b18'; TEAL='#16796d'

def generate(dataset,plan,summary,root):
    validate(summary,plan)
    if digest(dataset)!=plan['dataset_understanding']['datasets'][0]['sha256']: raise ValueError('Dataset changed')
    root=Path(root); (root/'tables').mkdir(parents=True,exist_ok=True); (root/'figures').mkdir(exist_ok=True)
    expected=['distribution_full_and_central','quartiles_and_observed_range','empirical_cumulative_distribution']
    if any(a['outputs']['figures']!=expected for a in plan['analysis_plan']):
        raise ValueError('Figure scope differs: review and approve the three-view descriptive plan before generating figures')
    frame=read_data(dataset); summary['artifacts']=[]
    def record(a,ident,path,caption,kind='figure'):
        a['artifacts'].append(ident)
        summary['artifacts'].append(dict(id=ident,analysis_id=a['analysis_id'],kind=kind,path=path,caption=caption))
    def export(fig,a,ident,path,caption):
        fig.savefig(root/path,dpi=180,bbox_inches='tight');plt.close(fig);record(a,ident,path,caption)
    for i,a in enumerate(summary['analyses'],1):
        a['artifacts']=[]
        if a['status']!='success': continue
        path=f'tables/analysis_{i}.csv'
        with (root/path).open('w',newline='',encoding='utf-8') as file:
            writer=csv.writer(file); writer.writerow(['variable',*next(iter(a['results'].values())).keys()])
            for v,r in a['results'].items(): writer.writerow([v,*r.values()])
        record(a,f'T{i}',path,'Observed descriptive statistics; sample SD uses n-1; missing values excluded per variable.','table')
        for j,(v,r) in enumerate(a['results'].items(),1):
            x=frame[v].dropna().to_numpy(dtype=float)
            meta=plan.get('report_context',{}).get('variables',{}).get(v,{})
            label=meta.get('label',v);unit=meta.get('unit','source units');xlabel=f'{label} ({unit})'
            prefix=f'analysis_{i}_variable_{j}'
            # A limited, shared set of bin edges avoids invisible bars for heavy tails.
            edges=np.histogram_bin_edges(x,bins=min(80,max(10,int(np.sqrt(len(x))))))
            fig,axes=plt.subplots(1,2,figsize=(12,4.6),layout='constrained')
            for ax in axes:
                ax.hist(x,bins=edges,color=BLUE,alpha=.85,edgecolor='white',linewidth=.35)
                ax.axvline(r['median'],color=ORANGE,linewidth=1.6,label='Median')
                ax.set_xlabel(xlabel);ax.grid(axis='y',alpha=.15)
            axes[0].set(title='Full range: tails retained',ylabel='Record count (log scale)',yscale='log')
            axes[0].legend(frameon=False)
            width=r['iqr'] if r['iqr']>0 else max(abs(r['median'])*.1,1.)
            axes[1].set_xlim(r['q1']-1.5*width,r['q3']+1.5*width)
            axes[1].set(title='Central view: same data and bins',ylabel='Record count')
            axes[1].yaxis.set_major_locator(MaxNLocator(integer=True))
            fig.suptitle(f'{a["rq_id"]} | Distribution shape · {label}',fontsize=14)
            export(fig,a,f'F{i}_{j}_hist',f'figures/{prefix}_hist.png','Full-range histogram uses a logarithmic count axis to reveal sparse tails. The companion panel changes only the view limits; no observations are removed. Median is marked.')
            # Box statistics come from stored results; full-range whiskers avoid unapproved trimming.
            fig,ax=plt.subplots(figsize=(10,3.7),layout='constrained')
            ax.bxp([dict(med=r['median'],q1=r['q1'],q3=r['q3'],whislo=r['min'],whishi=r['max'],fliers=[])],vert=False,patch_artist=True,boxprops={'facecolor':'#cce3eb'},medianprops={'color':ORANGE,'linewidth':2},showfliers=False)
            for key in ['q1','median','q3']:
                ax.plot(r[key],1,'o',color=TEAL,markersize=4)
            ax.set(yticks=[],xlabel=xlabel,title=f'{a["rq_id"]} | Quartiles and observed range')
            ax.text(.02,.04,f'Q1 = {r["q1"]:.4g}  |  Median = {r["median"]:.4g}  |  Q3 = {r["q3"]:.4g}\nIQR = {r["iqr"]:.4g} {meta.get("spread_unit",unit)}',transform=ax.transAxes,fontsize=10)
            ax.grid(axis='x',alpha=.2)
            export(fig,a,f'F{i}_{j}_box',f'figures/{prefix}_box.png','Box spans Q1 to Q3 with the median marked. Whiskers extend to the observed minimum and maximum (not 1.5-IQR outlier fences); all finite values are retained.')
            fig,ax=plt.subplots(figsize=(10,4.6),layout='constrained')
            xs,counts=np.unique(x,return_counts=True);ys=np.cumsum(counts)/len(x)
            padding=max(float(xs[-1]-xs[0])*.02,abs(float(xs[0]))*.02,1e-6)
            ax.step(np.r_[xs[0]-padding,xs,xs[-1]+padding],np.r_[0.,ys,1.],where='post',color=BLUE,linewidth=1.8)
            for quantile,prob in [('q1',.25),('median',.5),('q3',.75)]:
                ax.axvline(r[quantile],color=TEAL,alpha=.45,linestyle='--');ax.axhline(prob,color='#809299',alpha=.35,linestyle=':')
            ax.set(xlabel=xlabel,ylabel='Cumulative fraction of observed records',ylim=(0,1.02),title=f'{a["rq_id"]} | Empirical cumulative distribution')
            ax.grid(alpha=.15)
            export(fig,a,f'F{i}_{j}_ecdf',f'figures/{prefix}_ecdf.png','Empirical cumulative distribution of all non-missing values. Reference lines mark stored quartiles and cumulative fractions; this is not a forecast probability distribution.')
    validate(summary,plan,root)
    return summary

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('dataset'); p.add_argument('plan'); p.add_argument('summary')
    a=p.parse_args(); save(a.summary,generate(a.dataset,load(a.plan),load(a.summary),Path(a.summary).parent))
