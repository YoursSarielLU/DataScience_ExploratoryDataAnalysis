# -*- coding: utf-8 -*-
"""Record an already received user decision. Never infer approval from a task to analyze."""
import argparse
from datetime import datetime, timezone
from common import load, save, check_plan, plan_digest

def approve(plan, confirmation):
    if not confirmation.strip(): raise ValueError('Actual user confirmation required')
    plan['approval'].update(status='approved',approved_at=datetime.now(timezone.utc).isoformat(),plan_sha256=plan_digest(plan),user_confirmation=confirmation)
    check_plan(plan,approved=True)
    return plan

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('plan'); p.add_argument('--user-confirmation',required=True,help='Exact confirmation already received from the user, not agent-generated approval')
    a=p.parse_args(); plan=approve(load(a.plan),a.user_confirmation); save(a.plan,plan)
