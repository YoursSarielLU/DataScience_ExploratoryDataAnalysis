# -*- coding: utf-8 -*-
"""Deterministic planning helper; the agent must review semantics and assignment constraints."""
import argparse
import re
from pathlib import Path
from common import inspect, save, check_plan, SECTIONS

CAUSAL=re.compile(r'\b(caus\w*|prove|effect of|impact of)\b|导致|因果|证明',re.I)

def propose(dataset, goal=None, variables=None, method=None, intent='description', assignment=None):
    understanding=inspect(dataset)
    variables=variables or []
    known={v['name']:v['semantic_type'] for v in understanding['variables']}
    plan=dict(task_context=dict(task_type='coursework',assignment_summary=assignment,user_goal=goal,output_format='both',constraints=dict(word_limit=None,required_methods=[],prohibited_methods=[],required_sections=[],deadline=None)),dataset_understanding=understanding,research_objective=dict(statement=goal or 'Select a research direction supported by the dataset.',origin='user' if goal else 'agent_proposed'),research_questions=[],analysis_plan=[],methodological_warnings=[],approval=dict(status='pending',approved_at=None,user_modifications=[],plan_sha256=None,user_confirmation=None))
    def warn(issue, severity='warning', suggested=None):
        plan['methodological_warnings'].append(dict(id=f"W{len(plan['methodological_warnings'])+1}",rq_id='RQ1' if goal else None,severity=severity,issue=issue,requested_method=method,suggested_method=suggested,requires_user_decision=True))
    if assignment:
        warn('Agent must map assignment requirements into task_context.constraints and resolve conflicts before approval.')
    if goal:
        selected_method=method or ('descriptive_statistics' if intent=='description' else 'method_selection_required')
        answerable=bool(variables) and all(v in known for v in variables) and not CAUSAL.search(goal)
        plan['research_questions']=[dict(id='RQ1',question=goal,origin='user',research_intent=intent,variables=dict(outcome=variables,predictors=[],grouping=[],covariates=[]),rationale='Preserve the user question; agent must verify that the selected intent and variables answer it.',answerable=bool(answerable))]
        if not variables or any(v not in known for v in variables): warn('Required variables are absent or unspecified. Map variables with the user.','critical')
        if CAUSAL.search(goal): warn('Observational data cannot establish the requested causal claim. Propose an association question; preserve original wording until user decides.','critical','noncausal_research_question')
        if method=='pearson_correlation' and (len(variables)!=2 or any(known.get(v)!='continuous' for v in variables)):
            warn('Pearson requested without two confirmed continuous variables. Check category coding and study design; two independent groups may support Welch t-test. Binary coding can admit point-biserial interpretation, but requires explicit design review.',suggested='welch_t_test_after_design_review')
        if variables:
            plan['analysis_plan']=[dict(id='A1',rq_id='RQ1',method_family=intent,proposed_method=selected_method,variables=variables,rationale='For a descriptive RQ, summarize observed quantitative distributions, spread and missingness without population or causal inference.' if selected_method=='descriptive_statistics' else 'User method preserved; suitability and rationale require review before execution.',assumptions_to_check=['semantic type and numeric values','finite observed values','missingness and sample size'] if selected_method=='descriptive_statistics' else ['study design, variable coding and method-specific suitability require review'],fallback_method=None,outputs=dict(tables=['descriptive_statistics'],figures=['distribution_full_and_central','quartiles_and_observed_range','empirical_cumulative_distribution']) if selected_method=='descriptive_statistics' else dict(tables=[],figures=[]))]
        if selected_method=='descriptive_statistics' and (intent!='description' or any(known.get(v)!='continuous' for v in variables)):
            warn('This runner requires a descriptive RQ with confirmed continuous variables. Do not treat identifiers or category codes as quantitative measurements.','critical')
        if selected_method!='descriptive_statistics':
            warn('Method is reference-supported but not implemented in the Sprint 1 runner; retain requested method and discuss next implementation step.')
    check_plan(plan)
    return plan

def proposal_text(plan, method_was_supplied=False):
    ctx=plan['task_context']; rqs=plan['research_questions']
    level=4 if rqs and method_was_supplied else (3 if rqs else (2 if ctx['assignment_summary'] else 1))
    lines=['# Research Proposal',f'Autonomy: Level {level} (agent must verify input completeness).',plan['research_objective']['statement']]
    if not rqs:
        candidates=[v['name'] for v in plan['dataset_understanding']['variables'] if v['semantic_type']=='continuous']
        if candidates:
            names=', '.join(candidates[:3])
            lines += [f'Candidate direction 1: Describe typical values and spread of {names}.',f'Candidate direction 2: Characterize distribution shape and unusual observations in {names}.',f'Candidate direction 3: Examine completeness of {names} and how missingness limits a descriptive study.']
        else:
            lines += ['No confirmed quantitative measurements for this runner. Clarify coding and research goals; categorical summaries require a later engine extension.']
        lines += ['These are alternatives, not selected or approved analyses. Choose or revise a direction and map variables.']
    for rq in rqs: lines += [f"{rq['id']}: {rq['question']}",f"Variables: {', '.join(v for values in rq['variables'].values() for v in values)}; answerable: {rq['answerable']}"]
    for a in plan['analysis_plan']:
        lines += [f"{a['id']}: {a['proposed_method']} — {a['rationale']}",f"Checks: {', '.join(a['assumptions_to_check'])}",f"Expected tables: {', '.join(a['outputs']['tables']) or 'pending method review'}; figures: {', '.join(a['outputs']['figures']) or 'pending method review'}"]
    lines += [f"Risk {w['id']} ({w['severity']}): {w['issue']} Suggested: {w['suggested_method']}" for w in plan['methodological_warnings']]
    lines += ['Report: '+' → '.join(SECTIONS),'Decision required: Approve / Modify / Reject. No formal analysis has run.']
    return '\n\n'.join(lines)+'\n'

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('dataset'); p.add_argument('--goal'); p.add_argument('--variables',nargs='+'); p.add_argument('--method'); p.add_argument('--intent',default='description'); p.add_argument('--assignment'); p.add_argument('--output',required=True)
    a=p.parse_args(); plan=propose(a.dataset,a.goal,a.variables,a.method,a.intent,a.assignment)
    save(a.output,plan); Path(a.output).with_suffix('.md').write_text(proposal_text(plan,method_was_supplied=a.method is not None),encoding='utf-8')
