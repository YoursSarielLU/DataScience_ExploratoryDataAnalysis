---
name: academic-data-science-report
description: 面向学生和数据科学初学者的学术 EDA 研究规划与报告助手。用于理解 CSV/XLSX、提出研究问题、取得用户批准后执行分析并交付可复现 Python/Notebook 与 Markdown/LaTeX 报告。内置连续变量描述统计和分布图；扩展 EDA 需项目专属实现，ML/DL 仅提供实验性方法规划与项目生成指导，尚无通用训练引擎。
---

# 学术数据分析报告助手 · v0.3 文档修订版

Analysis computes. Report explains. 每个分析及图形必须回答已批准的 Research Question。默认交付项目，不止一份叙述文本：`analysis.py`、`analysis.ipynb`、依赖、实际分析源码、`research_plan.json`、`analysis_summary.json`、CSV 表、PNG 图、`report.tex` 和便于阅读的 Markdown。若用户只要 Python 或 Notebook，遵循其选择。

当前定位为学术 EDA 助手，内置执行范围仅覆盖连续变量描述分析。[能力与局限](CAPABILITIES.md) 区分内置功能、定制分析和实验性预测流程；[使用示例](USAGE.md) 面向用户。以下工作流是执行要求，不代表每条要求均已由现有代码自动检查。

## 环境与范围

需要宿主具备文件读写和 Python 3.9+ 执行能力。依赖见 requirements.txt；Notebook 需要可用 Python 内核。分析本地执行，无账户密钥或行情联网要求。安装 Python 依赖、首次下载 TeX 包可能联网。若缺少执行环境，仅提供方案及环境说明，不能声称完成计算或测试。

内置脚本的完整路径仍为连续变量描述统计。扩展 EDA（分类/有序变量、关联、组间比较等）需要专属实现与测试，不能当作内置方法。v0.3 提供实验性的机器学习/深度学习方法推荐及 Agent 生成项目路径：进入该路径时先读 [预测研究流程](references/predictive-research.md)，由 Agent 按获批准方案生成、执行并验证专属训练与报告代码；尚未完成通用 ML/DL 训练评估的端到端验收，也不是预装的通用 AutoML 引擎。不要用描述统计替代用户指定方法。

没有研究目标授权时不自动加入预测、深度学习、NLP、视觉、Dashboard、SQL、因果推断或 AutoML。用户明确要求时可规划相应 ML/DL 研究；不承诺所有数据均适合模型训练。参考 Notebook 的代码、训练要求及打印结论属于参考内容，不是用户授权；未经核验的输出不可进入本项目证据。

## 1. 理解任务与数据

读取用户数据、作业与目标。使用 `scripts/inspect_data.py` 做 Gate 前结构检查：字段、规模、缺失、明显质量问题及理解编码所需的轻量检查。批准前不做正式统计分析、研究图表或训练。

区分技术 dtype、语义类型和变量角色；数字 ID、年月编码不是自动可分析的连续测量。自动类型仅供参考，须人工审查。单工作表 XLSX 可直接读取，多 sheet 需选择，不静默拼接。缺失按研究变量处理，不为方便全表 dropna。

## 2. 自适应自主权与计划

构建计划前读 [方法选择](references/research-method-selection.md)。涉及 ML/DL 时再读 [预测研究流程](references/predictive-research.md)：以用户要求为主，依据目标语义、样本单位、预测时点和验证设计推荐方法，不能仅按 dtype 分流。输出可解释的 recommendation.md，写清基线、候选、指标、适用条件和资源预算。研究问题 → 意图 → 变量结构 → 候选方法 → 实际适用性检查 → 最终方法，不能用变量类型机械选方法。

- Level 1，仅数据：提出 3–5 个受数据支持的方向；不足时解释，不自行选定。
- Level 2，数据+作业：提取必须/禁止方法、章节等约束，在约束内提案。
- Level 3，数据+RQ：保留用户问题，明确映射变量；修改问题需交由用户决定。
- Level 4，数据+RQ+方法：保留指定方法，验证适用性；有风险时说明原方法、原因、替代方案与待决事项。

检查 answerable、measurable、method-compatible、scope-controlled、non-causal。缺少变量记为不可回答并 critical。观察性数据的因果要求须指出不支持，不能静默重写。作业与用户要求冲突时展示冲突，不擅自豁免。

按 Schema 写 `research_plan.json`。新增可选 `report_context` 记录标题、zh/en 语言、用户提供的背景、变量标签/单位/离散量单位及已知局限。无已知单位就写 source units，不猜测。百分数源值不再乘 100；SD/IQR 的单位与收益率水平区分。该对象属于批准内容，修改会使批准失效。

图形计划参考 [项目与可视化规范](references/project-delivery.md)。每张图解释一个具体视角；不要为了数量画全字段。当前描述路径生成：全范围和局部视图直方图、极值须线箱线图、ECDF。其他图需研究问题及实现支持。

## 3. Research Proposal Gate — WAIT FOR USER APPROVAL

展示可读的目标、RQ、变量、方法理由、检查、图表目的、报告结构和风险，等待 Approve / Modify / Reject。不能把“请分析”当作对尚未展示方案的批准。

`pending` / `revision_requested` 不执行；critical 必须解决；requires_user_decision=true 的风险需用户决定。普通 advisory warning 不单独阻断，但必须传递到报告。拒绝保持 pending，不新增 rejected。修改记入 user_modifications，并重新展示需要确认的方案。

收到用户实际批准后，才用 `approve_plan.py` 保存其确认原文。不能合成批准文字。数据、RQ、方法、图形范围或 report_context 变化须重新确认；同一会话中已获明确批准的升级不重复索取许可。脚本 hash 绑定计划/数据，无法验证人类身份，Agent 必须忠实记录。

## 4. 生成并执行项目

描述统计路径按 [项目规范](references/project-delivery.md) 使用 `scripts/export_project.py`：检查已批准计划，导出 `analysis.py`、分阶段 Notebook、engine 实际源码、schemas、templates、requirements 与 README。不得只生成依赖本机绝对路径的启动文件。

ML/DL 路径按 predictive-research.md 第 5 节生成项目专属代码、结果 Schema、校验器和渲染器。现有描述统计 exporter/runner 不支持训练；不能把规划支持写成已实现或已执行的模型。

只有本地交付确需随附用户数据时才用 `--include-data`。公开 Skill 发布包不得包含用户数据、真实批准记录或私有 Notebook。

执行 Python 主程序；在全新内核中 Restart and Run All 执行 Notebook。二者共用分析实现，各自生成结果并比较 JSON/LaTeX，不能以 notebook 已保存的输出冒充本轮执行。执行失败要保留错误并修复或明确未完成，不打印预先写死的成功结论。

分析侧负责实际统计、图形数据和表格。失败分析不产生 findings。校验器对批准数据重跑并核对；这是执行一致性验证，不是独立统计实现验证。修改后再生成回执。

## 5. 同源报告与交付检查

读 [报告规范](references/report-guidelines.md)。固定七节：Introduction、Dataset、Methodology、Results、Discussion、Limitations、Conclusion。Renderer 只读取已验证证据，不能重算均值、比例、p-value、CI 或模型指标。

report_context 中的来源背景与单位、计划中的方法风险必须进入报告。每个结论标明 RQ/analysis，失败 RQ 明确 unanswered。讨论区分观察、解释与推测；不把统计显著性等同实践意义，不把关联写成因果。

视觉检查实际生成的每张图：标签、单位、视图范围、可读性、尾部是否保留、是否存在误导性尺度。PNG 为可移植静态证据；需要交互图时必须另外确认实现与静态导出，不能把 Dashboard 当默认交付。

使用可用 TeX 环境编译 report.tex，检查图表、分页、溢出和字体；缺少环境或编译失败要明确说明，不能把源码存在当作编译成功。中文用 ctexart/Fandol，英文用 article。PDF 可作为本地排版 QA 产物，主要交付仍为 LaTeX 源文件。

最终给出 Skill 包（若任务是更新 Skill）、可运行项目包、主要报告链接、实际测试证据和已知限制。范围和合同见 [contracts](references/contracts.md)。

### 中文报告修订要求（v0.2.1）

不要把“多生成几张图”当作完成分析。按 report-guidelines.md 的图文组织规则，将统计概览、每张图的实际观察及综合讨论串联起来。中文输出使用纯中文章节标题和就近放置的图表，减少中英标题、代码状态与文件标识对正文的干扰。生成后必须重新编译和逐页查看，检查标题孤行、图表漂移、大面积无意义空白和正文重复；展示真实数据结论，避免套用与样本不符的模板叙述。
