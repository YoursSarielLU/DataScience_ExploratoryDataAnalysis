# -*- coding: utf-8 -*-
import sys,unittest,tempfile,subprocess,shutil,json,math
from pathlib import Path
from unittest.mock import patch
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from common import save,load,digest,plan_digest
from propose_research import propose
from approve_plan import approve
from run_analysis import run
from generate_figures import generate
from validate_results import verify
from render_report import render
from export_project import export

class DeliveryTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name);self.data=self.root/'data.csv'
  pd.DataFrame({'score':[10.,20.,30.,40.,None,50.]}).to_csv(self.data,index=False)
 def tearDown(self):self.temp.cleanup()
 def plan(self):
  p=propose(self.data,'Describe the observed score distribution',['score'])
  p['report_context']={'title':'Test report','language':'en','background':['Synthetic fixture only.'],'variables':{'score':{'label':'Score','unit':'%','spread_unit':'percentage points'}},'limitations':['SOURCE BASIS UNKNOWN']}
  p['methodological_warnings']=[dict(id='W1',rq_id='RQ1',severity='warning',issue='ADVISORY RISK',requested_method=None,suggested_method=None,requires_user_decision=False)]
  return approve(p,'SYNTHETIC TEST APPROVAL')
 def test_portable_project_and_report_evidence(self):
  p=self.plan();save(self.root/'plan.json',p)
  out=export(self.root/'plan.json',self.data,self.root/'project',True)
  moved=self.root/'relocated';shutil.move(out,moved)
  result=subprocess.run([sys.executable,str(moved/'analysis.py')],cwd=self.root,check=True,capture_output=True,text=True)
  summary=load(moved/'report/analysis_summary.json');r=summary['analyses'][0]['results']['score']
  self.assertEqual(r['mean'],30);self.assertAlmostEqual(r['sd'],math.sqrt(250))
  self.assertEqual(len(summary['artifacts']),4)
  tex=(moved/'report/report.tex').read_text();self.assertIn('SOURCE BASIS UNKNOWN',tex);self.assertIn('ADVISORY RISK',tex);self.assertIn('percentage points',tex);self.assertIn('tabular',tex)
  self.assertEqual(len(list((moved/'report/figures').glob('*.png'))),3)
  self.assertNotIn('/Users/',(moved/'analysis.py').read_text())
  with patch('run_analysis.run',side_effect=AssertionError('Renderer recalculated')):
   render(moved/'research_plan.json',moved/'report/analysis_summary.json',moved/'report/validation.json')
 def test_pending_gate_and_changed_context(self):
  p=self.plan();p['approval']['status']='pending'
  with self.assertRaises(ValueError):run(self.data,p)
  p=self.plan();p['report_context']['variables']['score']['unit']='changed'
  with self.assertRaisesRegex(ValueError,'Plan changed'):run(self.data,p)
 def test_changed_data_and_unapproved_figures(self):
  p=self.plan();summary=run(self.data,p);p['analysis_plan'][0]['outputs']['figures']=['histogram']
  p=approve(p,'SYNTHETIC new figure plan')
  with self.assertRaisesRegex(ValueError,'Figure scope'):generate(self.data,p,summary,self.root)
  p=self.plan();self.data.write_text('score\n100\n')
  with self.assertRaisesRegex(ValueError,'Dataset changed'):run(self.data,p)
 def test_nonfinite_empty_and_constant(self):
  for vals in [[None,None],[1.,2.,float('inf')],[3.,3.,3.],[3.]]:
   pd.DataFrame({'score':vals}).to_csv(self.data,index=False);p=self.plan();s=run(self.data,p)
   s=generate(self.data,p,s,self.root);verify(s,p,self.data,self.root)
   if vals[0] is None or float('inf') in vals:
    self.assertEqual(s['analyses'][0]['status'],'failed');self.assertEqual(s['artifacts'],[])
   else:self.assertEqual(len(s['artifacts']),4)
 def test_forged_value_and_stale_receipt(self):
  p=self.plan();s=run(self.data,p);s['analyses'][0]['results']['score']['mean']=999
  with self.assertRaisesRegex(ValueError,'differs'):verify(s,p,self.data,self.root)
 def test_chinese_narrative_uses_stored_evidence(self):
  p=self.plan();p['report_context']['language']='zh';p=approve(p,'SYNTHETIC report-language approval')
  summary=generate(self.data,p,run(self.data,p),self.root);save(self.root/'plan.json',p);save(self.root/'analysis_summary.json',summary)
  save(self.root/'validation.json',dict(plan_sha256=plan_digest(p),summary_sha256=digest(self.root/'analysis_summary.json'),artifacts={a['path']:digest(self.root/a['path']) for a in summary['artifacts']}))
  with patch('run_analysis.run',side_effect=AssertionError('Renderer recalculated')):
   render(self.root/'plan.json',self.root/'analysis_summary.json',self.root/'validation.json')
  tex=(self.root/'report.tex').read_text()
  self.assertIn('30.0000',tex);self.assertIn('SOURCE BASIS UNKNOWN',tex);self.assertIn('ADVISORY RISK',tex)
  self.assertEqual(tex.count('includegraphics'),3)
  self.assertNotIn('begin{figure}',tex)
  self.assertIn('section{讨论',tex)
  self.assertEqual(load(self.root/'analysis_summary.json'),summary)
 def test_export_cannot_approve(self):
  p=self.plan();p['approval']['status']='pending';save(self.root/'plan.json',p)
  with self.assertRaises(ValueError):export(self.root/'plan.json',self.data,self.root/'project',True)

if __name__=='__main__':unittest.main()
